/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg5iapp01;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author Francesco
 */
public class Main extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        /*creo gli oggetti visuali per la mia interfaccia */
        Label lNumero = new Label("Numero:");
        TextField txtNumero = new TextField();
        Button btnDivisori = new Button();
        Label lRisultato = new Label();
        
        btnDivisori.setText("Visualizza Divisori");
        btnDivisori.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                //System.out.println("Hello World!");
                
                // 1° recupero il contenuto della cella di testo.
                String txt = txtNumero.getText();
                // 2° converto la stringa in valore intero.
                int numero = Integer.parseInt(txt);
                //3° realizzo il ciclo for per i divisori.
                /*System.out.print("Divisori di "+numero+": ");
                for(int i=1; i<=numero; i++){
                    if(numero%i == 0)
                        System.out.print(i+" ");
                }
                System.out.print("\n\n");*/
                String risultato = "Divisori di "+numero+": ";
                for(int i=1; i<=numero; i++){
                    if(numero%i == 0)
                        risultato += i+" ";
                }
                lRisultato.setText(risultato);
            }
        });
        
        /* Inizializzo la Scena utilizzando un layout Verticale */
        //StackPane root = new StackPane();
        /*VBox root = new VBox();
        root.getChildren().add(lNumero);
        root.getChildren().add(txtNumero);
        root.getChildren().add(btnDivisori);
        root.getChildren().add(lRisultato);*/
        
        VBox root = new VBox();
        HBox row1 = new HBox();
        row1.getChildren().add(lNumero);
        row1.getChildren().add(txtNumero);
        
        root.getChildren().add(row1);
        root.getChildren().add(btnDivisori);
        root.getChildren().add(lRisultato);
        
        Scene scene = new Scene(root, 300, 250);
        
        primaryStage.setTitle("Calcolo Divisori Intero");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
