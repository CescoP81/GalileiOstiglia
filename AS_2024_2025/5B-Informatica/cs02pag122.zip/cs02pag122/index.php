<?php
// questo file è nella root del caso studio in sviluppo esegue
// un redirect alla cartella della versione da utilizzare.
header("location: ./2.0");
exit;
?>