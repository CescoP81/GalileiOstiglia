<?php
// questo file è nella root della versione in sviluppo e esegue
// un redirect alla cartella del core PHP da usare.
header("location: ./php");
exit;
?>