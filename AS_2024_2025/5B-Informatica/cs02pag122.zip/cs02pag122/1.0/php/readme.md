Questo folder contiene tutto il pacchetto di pagine che operano sul nostro gestionale,
il Core della nostra applicazione.