Questo folder contiene tutta la documentazione realizzata per lo sviluppo
del caso studio, in particolare:
- testo dell'esercizio preso in esame.
- diagramma ER svilupparo in Draw.io, nominato come 'er.drawio.png'
- Testo con vincoli e funzionalità che si prevede di realizzare per il caso studio, nominato 'version.txt'.