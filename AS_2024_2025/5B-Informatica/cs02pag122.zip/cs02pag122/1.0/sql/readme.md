Questo folder contiene i seguenti file:
- ddl.sql -> definizione delle tabelle che costituiscono la banca dati.
- dml.sql -> prima popolazione della banca dati per verifiche delle query successive.
- query.sql -> Eventuali query di prova/verifica del corretto funzionamento della banca dati.