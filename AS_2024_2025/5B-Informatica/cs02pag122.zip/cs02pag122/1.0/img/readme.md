Questo folder contiene tutte le eventuali immagini che vengono
caricate nell'interfaccia del progetto.